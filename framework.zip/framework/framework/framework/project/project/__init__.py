#配置数据库
import pymysql
pymysql.install_as_MySQLdb()
