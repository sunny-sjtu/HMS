#与第一次迭代无关，不用管
from django.apps import AppConfig

class MyappConfig(AppConfig):
    name = 'myApp'
